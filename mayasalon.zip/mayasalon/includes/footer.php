
        <section id="footer">

        <img src="./images/wavefooter.svg" alt="" class="wave img-fluid">

            <div class="container">
                <div class="row">
               
                </div>
                <div class="row">
                <div class="col-sm" data-aos="fade-up">
                        <img src="images/mayalogolong.svg" alt="logomayasalon" class="logopanjangsalon" style="margin-bottom:10px;">
                    </div>
                    
                    <div class="col-sm" data-aos="fade-up">
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Netus et malesuada fames ac turpis egestas integer eget aliquet. Sapien eget mi proin sed.</p>
                    </div>
                    
                    <div class="col-sm" data-aos="fade-up">
                        <div class="social-icons-box">
                            <div class="social-icons-list">
                                <ul>
                                    <li><a href="https://instagram.com/maya_jehaut"><i class="fab fa-instagram"></i></a></li>
                                    <li><a href="https://api.whatsapp.com/send?phone=6287761392077"><i class="fab fa-whatsapp"></i></a></li>
                                    <li><a href="https://goo.gl/maps/AK8XE8uCS9Y829iw5"><i class="fas fa-map-marked-alt"></i></a></li>
                                    <li><a href=""><i class="far fa-envelope"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <br>
                <div class="row">
                    <div class="col" data-aos="fade-up">
                    <ul class="nav justify-content-center">
                        <li class="nav-item">
                          <a class="nav-link active" href="index.php">Halaman Utama</a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" href="tentangkami.php">Tentang Kami</a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" href="layanankami.php">Layanan Kami</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="galeri.php">Galeri Kami</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="katalog.php">Katalog</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="hubungikami.php">Hubungi Kami</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Terms & Conditions</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="login.php">Login</a>
                        </li>
                      </ul>
                    </div>
                </div><br>
                <div class="row">
                    <div class="col" >
                        <h6 align="center">Made By Valentino Y. Jehaut &copy; <script>document.write(new Date().getFullYear())</script></h6>
                    </div>
                </div>
                
            </div>
        </section>
        <?php include("scripts.php"); ?>
    </body>
</html>